export class Admin {
    username: string;
    pass: string;
    id: number;
    constructor(username: string,
        pass: string, id: number) {
        this.username = username;
        this.pass = pass;
        this.id = id;
    }

}